setwd("C:\\Users\\IT24102032\\Desktop\\IT24102032")

DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE)

head(DeliveryTimes)

breaks <- seq(20, 70, length.out = 10)

hist(DeliveryTimes$Delivery_Time_.minutes., 
     breaks = breaks, 
     right = FALSE,   # Right-open intervals,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

summary(DeliveryTimes$Delivery_Time_.minutes.)
mean(DeliveryTimes$Delivery_Time_.minutes.)
median(DeliveryTimes$Delivery_Time_.minutes.)


freq_table <- hist(DeliveryTimes$Delivery_Time_.minutes., 
                   breaks = breaks, 
                   right = FALSE, 
                   plot = FALSE)

cum_freq <- cumsum(freq_table$counts)

plot(freq_table$breaks[-1], cum_freq, 
     type = "o", 
     xlab = "Delivery Time .minutes.", 
     ylab = "Cumulative Frequency", 
     main = "Cumulative Frequency Polygon (Ogive)")
