#Set working directory
setwd ("//Users//dev//Desktop//IT24102032")

#Load dataset
data <- read.csv("Data.csv")
View(data)
str(data)

# Observed frequencies
customers <- c(55, 62, 43, 46, 50)
days <- c("Mon", "Tue", "Wed", "Thu", "Fri")

# Chi-square Goodness of Fit test
# H0: Customers come equally on all weekdays
# H1: Customers do NOT come equally on all weekdays
result1 <- chisq.test(customers, p = rep(1/5, 5))

# Show results
print(result1)

# Check expected frequencies
result1$expected

# Import the contingency table (from data.csv or online)
# If your Data.csv is a contingency table (13 rows × 4 columns):
# Columns: Wife, Alternately, Husband, Jointly
tasks <- read.csv("/Users/dev/Desktop/IT24102032/Data.csv", row.names = 1)

# View data
View(tasks)

# Perform Chi-square test of independence
# H0: No association between task type and distribution
# H1: There is an association
result2 <- chisq.test(tasks)

# Display results
print(result2)

# Expected frequencies
result2$expected

# Example: assume these are recorded purchases
snack_counts <- c(45, 39, 33, 43)   # Replace with your actual data if in CSV
snack_types <- c("A", "B", "C", "D")

# Chi-square Goodness of Fit test
# H0: Customers choose snacks equally (p=0.25 each)
# H1: Customers prefer some snacks more than others
result3 <- chisq.test(snack_counts, p = rep(1/4, 4))

# Display results
print(result3)
result3$expected